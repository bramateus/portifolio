var meus_campos = {
    'Email': 'email',
    'NomeCompleto': 'nome',
    'Telefone': 'telefone',
    'AceiteRegulamento': 'campo regulamento []',
    'EscolhaSeuCurso': 'area-de-interesse',
    'ComoConheceu': 'Como-Conheceu-Cotemar',
    'MelhorHorarioParaFalar': 'Horário'
};
options = { fieldMapping: meus_campos };
RdIntegration.integrate('48846f841a9ffae9900976dc64eb8aba', 'Pós por $99,90', options);